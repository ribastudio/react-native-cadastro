import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

export default () => (
  <View style={ Estilo.container }> 
    <Text> Meu Template </Text>
  </View>
)

const Estilo = StyleSheet.create(
  {
    container: {
      flexGrow: 1,
      justifyContent: 'center',
      alignItems: 'center'
    }
  }
)